jQuery(function(){
  alert('!!!!!!');
});